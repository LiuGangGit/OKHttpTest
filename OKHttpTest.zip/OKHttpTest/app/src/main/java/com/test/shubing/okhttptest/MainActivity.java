package com.test.shubing.okhttptest;

import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.test.shubing.okhttptest.okhttp.OkHttpFactory;
import com.test.shubing.okhttptest.okhttp.download.ProgressDownloader;
import com.test.shubing.okhttptest.okhttp.download.ProgressResponseBody;
import com.test.shubing.okhttptest.okhttp.upload.ProgressRequestBody;
import com.test.shubing.okhttptest.okhttp.upload.ProgressUploader;

import java.io.File;
import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity implements Callback, ProgressResponseBody.ProgressListener, ProgressRequestBody.ProgressRequestListener {

    public static final String PACKAGE_URL = "https://oss.aliyuncs.com/silverfox-document/2016-08/silverfox-official-v2.2.1.apk";


    private ProgressBar progressBar;
    private long breakPoints;
    private ProgressDownloader downloader;//下载工具类
    private ProgressUploader uploader;//上传工具类
    private File file;
    private long totalBytes;
    private long contentLength;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        progressBar = (ProgressBar) findViewById(R.id.progressbar);
    }


    private void postTest(String cellphone, String password) {
        FormBody.Builder builder = new FormBody.Builder();
        builder.add("cellphone", cellphone);
        builder.add("password", password);
        FormBody formBody = builder.build();
        OkHttpFactory.post("/user/login", formBody, this, "login");
    }

    //下载
    public void download(View view) {
        // 新下载前清空断点信息
        breakPoints = 0L;
        file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "sample.apk");
        downloader = new ProgressDownloader(PACKAGE_URL, file, this);
        downloader.download(0L);

    }

    //暂停
    public void stop(View view) {
        downloader.pause();
        Toast.makeText(this, "下载暂停", Toast.LENGTH_SHORT).show();
        // 存储此时的totalBytes，即断点位置。
        breakPoints = totalBytes;
    }

    //继续
    public void continueDown(View view) {
        downloader.download(breakPoints);
    }

    //上传
    public void upload(View view) {
        uploader = new ProgressUploader("", null, null, this);
        uploader.upload(this);
    }

    @Override
    public void onFailure(Call call, IOException e) {

    }

    @Override
    public void onResponse(Call call, Response response) throws IOException {
        String tag = (String) call.request().tag();
        Log.e("请求标志------->", tag);
        if ("order".equals(tag))
            Log.e("订单请求结果------->", response.body().string());
        if ("login".equals(tag))
            Log.e("登录请求结果------->", response.body().string());
        if (ProgressUploader.class.getSimpleName().equals(tag)) {
            //TODO:上传后回调
        }
    }

    @Override
    public void onPreDownload(long contentLength) {
        // 文件总长只需记录一次，要注意断点续传后的contentLength只是剩余部分的长度
        if (this.contentLength == 0L) {
            this.contentLength = contentLength;
            progressBar.setMax((int) (contentLength / 1024));
        }
    }

    @Override
    public void downloadProgress(long totalBytes, boolean done) {
        // 注意加上断点的长度
        this.totalBytes = totalBytes + breakPoints;
        progressBar.setProgress((int) (totalBytes + breakPoints) / 1024);
        if (done) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(MainActivity.this, "下载完成", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    @Override
    public void onPreUpload(long contentLength) {

    }

    @Override
    public void uploadProgress(long bytesWritten, long contentLength, boolean done) {
        if (done) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(MainActivity.this, "上传完成", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}
