package com.test.shubing.okhttptest.okhttp;

import android.util.Log;

import com.test.shubing.okhttptest.BaseApplication;
import com.test.shubing.okhttptest.R;

import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;

/**
 * Created by shubing on 2016/8/28.
 */
public class OkHttpFactory {
    private static String TAG = OkHttpFactory.class.getSimpleName();

    private static final int CONNECTION_TIME_OUT = 18 * 1000;//建立连接超时时间
    public static final long DEFAULT_READ_TIMEOUT_MILLIS = 15 * 1000;
    public static final long DEFAULT_WRITE_TIMEOUT_MILLIS = 20 * 1000;
    private static final long HTTP_RESPONSE_DISK_CACHE_MAX_SIZE = 10 * 1024 * 1024;

    private static OkHttpClient client;
    private static String BASE_URL;


    public static OkHttpClient getHttpClient() {
        return client;
    }

    static {
        BASE_URL = BaseApplication.resources().getString(R.string.host_url);
    }

    public static void setOkHttpClient() {
        client = new OkHttpClient.Builder().connectTimeout(CONNECTION_TIME_OUT, TimeUnit.MILLISECONDS)
                .readTimeout(DEFAULT_READ_TIMEOUT_MILLIS, TimeUnit.MILLISECONDS)
                .writeTimeout(DEFAULT_WRITE_TIMEOUT_MILLIS, TimeUnit.MILLISECONDS).build();
    }

    public static String getAbsoluteApiUrl(String partUrl) {
        String url = BASE_URL + partUrl;
        Log.e(TAG, "request:" + url);
        return url;
    }

    public static String getAbsoluteApiUrl(String partUrl, RequestParams params) {
        String url = BASE_URL + partUrl;
        String finalUrl = HttpHelper.getUrlWithQueryString(url, params);
        Log.e(TAG, "request:" + finalUrl);
        return finalUrl;
    }

    public static void get(String partUrl, Callback callback) {
        Request request = new Request.Builder().url(getAbsoluteApiUrl(partUrl)).build();
        Call call = client.newCall(request);
        call.enqueue(callback);//异步处理方式
    }

    public static void get(String partUrl, RequestParams params, Callback callback, String tag) {
        Request request = new Request.Builder().url(getAbsoluteApiUrl(partUrl, params)).tag(tag).build();
        Call call = client.newCall(request);
        call.enqueue(callback);//异步处理方式
    }

    public static void post(String partUrl, Callback callback) {

        Request request = new Request.Builder().url(getAbsoluteApiUrl(partUrl)).build();
        Call call = client.newCall(request);
        call.enqueue(callback);
    }

    public static void post(String partUrl, FormBody formBody, Callback callback, String tag) {

        Request request = new Request.Builder().url(getAbsoluteApiUrl(partUrl)).post(formBody).tag(tag).build();
        Call call = client.newCall(request);
        call.enqueue(callback);
    }
}
