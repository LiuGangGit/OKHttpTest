package com.test.shubing.okhttptest;

import android.app.Application;
import android.content.Context;
import android.content.res.Resources;

import com.test.shubing.okhttptest.okhttp.OkHttpFactory;

/**
 * Created by shubing on 2016/8/28.
 */
public class BaseApplication extends Application {

    static Context context;
    static Resources resources;

    @Override
    public void onCreate() {
        super.onCreate();
        context = getApplicationContext();

        resources = context.getResources();

        OkHttpFactory.setOkHttpClient();

    }

    public static Resources resources() {
        return resources;
    }
}
