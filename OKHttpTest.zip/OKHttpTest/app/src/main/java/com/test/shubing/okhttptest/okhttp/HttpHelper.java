package com.test.shubing.okhttptest.okhttp;

import android.util.Log;

import java.net.URI;
import java.net.URL;
import java.net.URLDecoder;

/**
 * Created by shubing on 2016/8/29.
 */
public class HttpHelper {
    public static String LOG_TAG = HttpHelper.class.getSimpleName();

    public static String getUrlWithQueryString(String url, RequestParams params) {
        if (url == null)
            return null;

        if (params != null) {
            String paramString = params.getParamString().trim();

            if (!paramString.equals("") && !paramString.equals("?")) {
                url += url.contains("?") ? "&" : "?";
                url += paramString;
            }
        }
        return url;
    }

}
