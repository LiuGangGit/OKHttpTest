package com.test.shubing.okhttptest.okhttp.upload;

import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;

import com.test.shubing.okhttptest.okhttp.OkHttpFactory;
import com.test.shubing.okhttptest.okhttp.upload.ProgressRequestBody.ProgressRequestListener;

import java.io.File;
import java.util.HashMap;
import java.util.List;

/**
 * Created by shubing on 2016/9/8.
 */
public class ProgressUploader {
    private static final String TAG = ProgressUploader.class.getSimpleName();

    private OkHttpClient client;
    private String url;
    private ProgressRequestListener progressRequestListener;
    private HashMap<String, String> params;
    private HashMap<String, List<File>> files;


    public ProgressUploader(String url, HashMap<String, String> params, HashMap<String, List<File>> files, ProgressRequestListener progressRequestListener) {
        this.progressRequestListener = progressRequestListener;
        this.url = url;
        this.params = params;
        this.files = files;
        client = OkHttpFactory.getHttpClient();
    }

    private void initParams(MultipartBody.Builder multipartBuild) {
        if (params != null && params.size() > 0) {
            for (String key : params.keySet()) {
                multipartBuild.addFormDataPart(key, params.get(key));
            }
        }
    }

    private void initFile(MultipartBody.Builder multipartBuild) {
        if (files != null && files.size() > 0) {
            for (String key : files.keySet()) {
                List<File> cFile = files.get(key);
                for (File file : cFile) {
                    RequestBody requestBody = RequestBody.create(MediaType.parse("application/octet-stream"), file);
                    multipartBuild.addFormDataPart(key, null, requestBody);
                }
            }
        }
    }

    public void upload(Callback callback) {
        MultipartBody.Builder multipartBuild = new MultipartBody.Builder();
        initParams(multipartBuild);
        initFile(multipartBuild);
        RequestBody requestBody = multipartBuild.setType(MultipartBody.FORM).build();
        ProgressRequestBody progressRequestBody = new ProgressRequestBody(requestBody, progressRequestListener);

        Request request = new Request.Builder().url(url).post(progressRequestBody).tag(TAG).build();
        client.newCall(request).enqueue(callback);
    }
}
